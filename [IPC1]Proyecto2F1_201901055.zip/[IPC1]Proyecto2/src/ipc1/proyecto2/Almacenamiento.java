package ipc1.proyecto2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JOptionPane;

public class Almacenamiento {
    
    private ObjectInputStream imp;
    private ObjectOutputStream outp;
    
    public void escribir(Object objeto){
        try{
            outp =new ObjectOutputStream(new FileOutputStream("Almacenamiento.bin"));
            outp.writeObject(objeto);
            outp.close();
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al escribir en el archivo: "+e);
        }
        
    }
    public Object leer(){
        Object tem;
        try{
            imp= new ObjectInputStream(new FileInputStream("Almacenamiento.bin"));
            tem=imp.readObject();
            return tem;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al leer en el archivo: "+e);
        }
        return null;
    }
    
}
