package ipc1.proyecto2;

import java.io.Serializable;
import javax.swing.JOptionPane;

public class Listas extends EstructuraDeDatos implements Serializable {

    private Nodo_usuario inicio;
    private int tamaño_lusuario;
    
    
    public Listas() {
        inicio = null;
        tamaño_lusuario = 0;
    }       

    public Nodo_usuario getnodousuario(String usu){ 
        Nodo_usuario copia = inicio;
        boolean existe = false;
        while (copia.getsiguiente() != null && existe == false) {
            if (usu == copia.getusuario()) {
                existe = true;
            } else {
                copia = copia.getsiguiente();
            }
        }
        
        return copia;
    }
   
    @Override
    public Object peek() {
        return inicio;
    }

    @Override
    public Object find(Object e) { //buscar un elemento

        Nodo_usuario copia = inicio;
        boolean existe = false;
        while (copia.getsiguiente() != null && existe == false) {
            if (e.toString() == copia.getusuario()) {
                existe = true;
            } else {
                copia = copia.getsiguiente();
            }
        }
       
        //JOptionPane.showMessageDialog(null, copia.getusuario());
        return copia.getusuario();
    }

    @Override
    public Object getNext() { //siguiente elemento 

        return inicio.getsiguiente().getusuario();

    }

    @Override
    public int getSize() {//tamaño de la estructura

        return tamaño_lusuario;

    }

    @Override
        public Object get(int i) {//objeto del indice i

        Nodo_usuario copia = inicio;
        for (int j = 0; j < i; j++) {
            copia=copia.getsiguiente();
        }
        return copia.getusuario();

    }

    @Override
    public Object pop() { //Retira el ultimo elemento o el primer elemento de la lista

        return inicio=inicio.getsiguiente();
    }

    @Override
    public void delete(Object e) {//Elimina un elemento
        Nodo_usuario aux = inicio;
        while (aux.getsiguiente() != null) {
            if (aux.getsiguiente().getusuario().equals(e.toString())) {
                    aux.setsiguiente(aux.getsiguiente().getsiguiente());
                break;
            }
            aux = aux.getsiguiente();
        }
    }

    @Override
    public void add(Object e) { //Añade un elemento

        Nodo_usuario nuevo = new Nodo_usuario();
        nuevo.setusuario(e.toString());
        if (inicio == null) {
            inicio = nuevo;
        } else {
            Nodo_usuario aux = inicio;
            while (aux.getsiguiente() != null) {
                aux = aux.getsiguiente();
            }
            aux.setsiguiente(nuevo);
        }
        tamaño_lusuario++;

    }
}
