package ipc1.proyecto2;

import java.io.File;
import java.io.Serializable;

public class Lista_Imagen extends EstructuraDeDatos implements Serializable{

    public Lista_Imagen() {
        primero = null;
        ultimo=null;
        tamaño = 0;
    }
    private Nodo_Imagen primero;
    private Nodo_Imagen ultimo;
    private int tamaño;

    @Override
    public void add(Object e) { //añadir un elemento

        Nodo_Imagen nuevo = new Nodo_Imagen((File) e, null, null);

        if (primero == null) {
            primero = nuevo;
            ultimo=nuevo;
            primero.setSiguiente(primero);
            primero.setAnterior(ultimo);

            } else {

            Nodo_Imagen aux = primero;
            for (int i = 0; i < tamaño-1; i++) {
                aux = aux.getSiguiente();
            }  
            aux.setSiguiente(nuevo);
            nuevo.setAnterior(aux);
        }
        tamaño++;

    }

    @Override
    public Object peek() {//Obtiene el ultimo o el primer elemento

        return primero.getImagen();
    }

    @Override
    public Object find(Object e) {//buscar un elemento
        Nodo_Imagen copia = primero;
        while (copia.getSiguiente() != null) {
            if (e == copia.getImagen()) {
                return copia.getImagen();
            } else {
                copia = copia.getSiguiente();
            }
        }
        //JOptionPane.showMessageDialog(null, copia.getusuario());
        return null;
    }

    @Override
    public Object getNext() {//siguiente elemento 
        return primero.getSiguiente().getImagen();
    }

    @Override
    public int getSize() {//tamaño de la estructura
        return tamaño;
    }

    @Override
    public Object get(int i) {//objeto del indice i
        Nodo_Imagen copia = primero;
        for (int j = 0; j < i; j++) {
            copia = copia.getSiguiente();
        }
        return copia.getImagen();
    }

    @Override
    public Object pop() {//Retira el ultimo elemento o el primer elemento de la lista
        return primero=primero.getSiguiente();
    }

    @Override
    public void delete(Object e) {//Elimina un elemento
        Nodo_Imagen aux = primero;
        for (int i = 0; i < (int)e-1; i++) {
            aux = aux.getSiguiente();
        }
        aux.setSiguiente(aux.getSiguiente().getSiguiente());
        tamaño--;
    }
}
