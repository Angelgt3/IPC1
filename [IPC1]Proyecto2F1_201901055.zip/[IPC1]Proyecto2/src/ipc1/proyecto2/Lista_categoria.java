package ipc1.proyecto2;

import java.io.Serializable;

public class Lista_categoria extends EstructuraDeDatos implements Serializable {

    private Nodo_categoria primero;
    private Nodo_categoria anterior;
    private int tamaño=0;
    public Lista_categoria() {
        //primero = new Nodo_categoria("General",primero,primero);
        //tamaño++;       
       // add("General");
        
    } 
    public Nodo_categoria nodocategoria(int i){
        Nodo_categoria copia = primero;
        for (int j = 0; j < i; j++) {
            copia=copia.getSiguiente();
        }
        return copia;
    }
    @Override
    public void add(Object e) { //añadir un elemento

        Nodo_categoria nuevo = new Nodo_categoria(e.toString(), null, null);
        
        if (primero == null) {
            primero = nuevo;
            anterior = nuevo;
        }
        else{
        
        Nodo_categoria aux = primero;
        while (aux.getSiguiente() != null) {
            aux = aux.getSiguiente();

        }
        aux.setSiguiente(nuevo);
        nuevo.setAnterior(aux);
        
        }
        tamaño++;
    }

    @Override
    public Object peek() { //Obtiene el ultimo o el primer elemento
        return primero;
    }

    @Override
    public Object find(Object e) { //buscar un elemento
       
        Nodo_categoria copia = primero;
        while (copia.getSiguiente() != null) {
       //     JOptionPane.showMessageDialog(null, "llego");
            if (e.toString() == copia.getCategoria()) {
                return copia.getCategoria();
            } else {
                copia = copia.getSiguiente();
            }
        }
        //JOptionPane.showMessageDialog(null, copia.getusuario());
        return null;
    }

    @Override
    public Object getNext() { //siguiente elemento 
        return primero.getSiguiente().getCategoria();
    }

    @Override
    public int getSize() { //tamaño de la estructura
        return tamaño;
    }

    @Override
    public Object get(int i) {//objeto del indice i
        Nodo_categoria copia = primero;
        for (int j = 0; j < i; j++) {
            copia=copia.getSiguiente();
        }
        return copia.getCategoria();
    }

    @Override
    public Object pop() {//Retira el ultimo elemento o el primer elemento de la lista
        return primero=primero.getSiguiente();
    }

    @Override
    public void delete(Object e) {//Elimina un elemento
        Nodo_categoria aux = primero;
        while (aux.getSiguiente()!= null) {
            if (aux.getSiguiente().getCategoria().equals(e.toString())) {
                aux.setSiguiente(aux.getSiguiente().getSiguiente());
                break;
            }
            aux = aux.getSiguiente();
        }
        
        tamaño--;
    }

}
