package ipc1.proyecto2;

import java.io.Serializable;


public class Nodo_usuario implements Serializable{

    private String usuario;
    private Nodo_usuario siguiente;
    public Lista_categoria categorias;
    
    public void Nodos() {
        usuario=null;
        siguiente = null;
        categorias=new Lista_categoria();
    }

    public String getusuario() {
        return usuario;
    }
    
    public void setusuario(String nuevo) {
        usuario = nuevo;
    }
    
    public Nodo_usuario getsiguiente() {
        return siguiente;
    }

    public void setsiguiente(Nodo_usuario siguiente) {
        this.siguiente = siguiente;
    }
    
}
