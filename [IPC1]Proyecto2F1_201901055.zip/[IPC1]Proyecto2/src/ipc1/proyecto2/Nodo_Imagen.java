
package ipc1.proyecto2;

import java.io.File;
import java.io.Serializable;

public class Nodo_Imagen implements Serializable{
    
    private File imagen;
    private Nodo_Imagen siguiente;
    private Nodo_Imagen anterior;
    

    public Nodo_Imagen(File imagen, Nodo_Imagen sig, Nodo_Imagen ant) {
        siguiente = sig;
        anterior = ant;
        this.imagen=imagen;
    }

    public File getImagen() {
        return imagen;
    }

    public Nodo_Imagen getSiguiente() {
        return siguiente;
    }

    public Nodo_Imagen getAnterior() {
        return anterior;
    }

    public void setImagen(File nueva) {
        imagen = nueva;
    }

    public void setSiguiente(Nodo_Imagen sig) {
        siguiente = sig;
    }

        public void setAnterior(Nodo_Imagen ant) {
        anterior = ant;
    }
    
}
