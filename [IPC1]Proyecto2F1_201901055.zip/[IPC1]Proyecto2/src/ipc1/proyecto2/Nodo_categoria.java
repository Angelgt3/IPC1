package ipc1.proyecto2;

import java.io.Serializable;

public class Nodo_categoria implements Serializable {

    private String categoria;
    private Nodo_categoria siguiente;
    private Nodo_categoria anterior;
    public Lista_Imagen imagenes;
    
    public Nodo_categoria(String categoria, Nodo_categoria sig, Nodo_categoria ant) {
        siguiente = sig;
        anterior = ant;
        this.categoria = categoria;
        imagenes=new Lista_Imagen();
        
    }
 
    
    public String getCategoria() {
        return categoria;
    }

    public Nodo_categoria getSiguiente() {
        return siguiente;
    }

    public Nodo_categoria getAnterior() {
        return anterior;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setSiguiente(Nodo_categoria sig) {
        siguiente = sig;
    }

    public void setAnterior(Nodo_categoria ant) {
        anterior = ant;
    }
}
